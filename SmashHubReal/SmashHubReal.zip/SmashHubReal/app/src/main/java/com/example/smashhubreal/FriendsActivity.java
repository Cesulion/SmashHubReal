package com.example.smashhubreal;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class FriendsActivity extends AppCompatActivity{
    RecyclerView.Adapter fAdapter;
    private FriendDbHelper mDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView friendsView = findViewById(R.id.friendsRV);
        friendsView.hasFixedSize();
        friendsView.setLayoutManager(new LinearLayoutManager(this));

        FriendDbHelper dbHelper = new FriendDbHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                FriendsContract.FriendsEntry.ID,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_FC};

        String[] selectWhere = {"0"};


        Cursor cursor = db.query(
                FriendsContract.FriendsEntry.TABLE_NAME,
                projection,
                FriendsContract.FriendsEntry.ID+" != ?",
                selectWhere,
                null,
                null,
                null,
                null);

        final ArrayList<FriendClass> friends = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                String friendUsername = cursor.getString(1);
                String friendFc = cursor.getString(2);
                String friendMain = cursor.getString(3);
                friends.add(new FriendClass(friendUsername, friendFc, friendMain));
            } while(cursor.moveToNext());
        }
        cursor.close();

        FriendsAdapter mAdapter = new FriendsAdapter(friends);
        friendsView.setAdapter(mAdapter);





        //fAdapter = new FriendsAdapter(friends);




    }
    public void MyCustomAlertDialog(final String id){
        final Dialog MyDialog = new Dialog(FriendsActivity.this);
        MyDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        MyDialog.setContentView(R.layout.customdialog);

        Button delete = (Button)MyDialog.findViewById(R.id.delete);
        Button close = (Button)MyDialog.findViewById(R.id.close);

        delete.setEnabled(true);
        close.setEnabled(true);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDatabase.deleteFriend(id);
                MyDialog.cancel();

                //refresh the activity
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDialog.cancel();
            }
        });

        MyDialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.myProfileItem:
                Intent profileIntent = new Intent(FriendsActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case R.id.homeitem:
                Intent homeIntent = new Intent(FriendsActivity.this, HomeActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.friendListItem:
                break;
            case R.id.tiersItem:
                Intent tiersIntent = new Intent(FriendsActivity.this, JsonActivity.class);
                startActivity(tiersIntent);
                break;

        }
        return super.onOptionsItemSelected(item);

    }
    public void addFriend (View v)
    {
        EditText nameEdit = findViewById(R.id.usernameAddET);
        EditText mainEdit = findViewById(R.id.mainAddET);
        EditText fcEdit = findViewById(R.id.fcAddET);
        FriendClass friend = new FriendClass();
        friend.setUsername(nameEdit.getText().toString());
        friend.setFc(fcEdit.getText().toString());
        friend.setMain(mainEdit.getText().toString());

        FriendDbHelper dbh = new FriendDbHelper(this);
        SQLiteDatabase db = dbh.getWritableDatabase();

        String[] projection = {
                FriendsContract.FriendsEntry.ID,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_FC};

        Cursor cursor = db.query(
                FriendsContract.FriendsEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);

        ContentValues values = new ContentValues();
        values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME, friend.getUsername());
        values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_FC, friend.getFc());
        values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN, friend.getMain());
        db.insert(FriendsContract.FriendsEntry.TABLE_NAME,null,values);
        nameEdit.setText("");
        fcEdit.setText("");
        mainEdit.setText("");
        cursor.close();
        recreate();
    }

}
