package com.example.smashhubreal;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle("No profile found");
        builder.setMessage("You need to create your profile");
        builder.setPositiveButton("Confirm",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });


        FriendDbHelper dbHelper = new FriendDbHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                FriendsContract.FriendsEntry.ID,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_FC};

        Cursor cursor = db.query(
                FriendsContract.FriendsEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);

        try {
                if (cursor.moveToFirst())
            {
                String[] selectWhere = {"0"};

                Cursor cursor2 = db.query(
                        FriendsContract.FriendsEntry.TABLE_NAME,
                        projection,
                        FriendsContract.FriendsEntry.ID+" = ?",
                        selectWhere,
                        null,
                        null,
                        null);

                int idColumnIndex = cursor2.getColumnIndex(FriendsContract.FriendsEntry.ID);
                int usernameColumnIndex = cursor2.getColumnIndex(FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME);
                int fcColumnIndex = cursor2.getColumnIndex(FriendsContract.FriendsEntry.COLUMN_FRIEND_FC);
                int mainColumnIndex = cursor2.getColumnIndex(FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN);

                if(cursor2.moveToFirst()==true){
                    int currentID = cursor2.getInt(idColumnIndex);
                    String currentUsername = cursor2.getString(usernameColumnIndex);
                    String currentFc = cursor2.getString(fcColumnIndex);
                    String currentMain = cursor2.getString(mainColumnIndex);

                    EditText usernameEdit = findViewById(R.id.usernameEdit);
                    EditText fcEdit = findViewById(R.id.fcEdit);
                    EditText mainEdit = findViewById(R.id.mainEdit);

                    usernameEdit.setText(currentUsername);
                    fcEdit.setText(currentFc);
                    mainEdit.setText(currentMain);
                    cursor2.close();
                    cursor.close();

                }





            }
                else
                {

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
        }
        finally {
            cursor.close();

        }



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        FriendDbHelper dbh = new FriendDbHelper(this);
        switch (item.getItemId()){
            case R.id.myProfileItem:
                break;
            case R.id.homeitem:
                Intent homeIntent = new Intent(ProfileActivity.this, HomeActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.tiersItem:
                Intent tiersIntent = new Intent(ProfileActivity.this, JsonActivity.class);
                startActivity(tiersIntent);
                break;
            case R.id.friendListItem:
                if(dbh.profileCreated())
                {
                    Intent flIntent = new Intent(ProfileActivity.this, FriendsActivity.class);
                    startActivity(flIntent);
                }
                else
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setCancelable(true);
                    builder.setTitle("No profile found");
                    builder.setMessage("You need to create your profile first.");
                    builder.setPositiveButton("Confirm",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });
                    builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;



        }
        return super.onOptionsItemSelected(item);
    }

    public void onSaveButton(View v)
    {
        EditText nameEdit = findViewById(R.id.usernameEdit);
        EditText mainEdit = findViewById(R.id.mainEdit);
        EditText fcEdit = findViewById(R.id.fcEdit);
        FriendClass self = new FriendClass();
        self.setUsername(nameEdit.getText().toString());
        self.setFc(fcEdit.getText().toString());
        self.setMain(mainEdit.getText().toString());


        FriendDbHelper dbh = new FriendDbHelper(this);
        SQLiteDatabase db = dbh.getWritableDatabase();

        if (dbh.profileCreated())
        {
            ContentValues values = new ContentValues();
            values.put(FriendsContract.FriendsEntry.ID, 0);
            values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME, self.getUsername());
            values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_FC, self.getFc());
            values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN, self.getMain());
            db.insert(FriendsContract.FriendsEntry.TABLE_NAME,null,values);
            db.update("friends", values, "_id="+0, null);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle("Profile updated");
            builder.setMessage("Yay.");
            builder.setPositiveButton("Confirm",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            AlertDialog dialog = builder.create();

            Intent homeIntent = new Intent(ProfileActivity.this, HomeActivity.class);
            startActivity(homeIntent);
            dialog.show();

        }

        else
        {
            ContentValues values = new ContentValues();
            values.put(FriendsContract.FriendsEntry.ID, 0);
            values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME, self.getUsername());
            values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_FC, self.getFc());
            values.put(FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN, self.getMain());
            db.insert(FriendsContract.FriendsEntry.TABLE_NAME,null,values);
            db.close();
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle("Your profile was created");
            builder.setMessage("Now the fun begins.");
            builder.setPositiveButton("Confirm",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            AlertDialog dialog = builder.create();

            Intent homeIntent = new Intent(ProfileActivity.this, HomeActivity.class);
            startActivity(homeIntent);
            dialog.show();
        }
        

    }




}
