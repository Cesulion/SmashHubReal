package com.example.smashhubreal;

import android.provider.BaseColumns;

public final class FriendsContract {
    private FriendsContract(){}
public class FriendsEntry implements BaseColumns {
    public static final String TABLE_NAME = "friends";
    public static final String ID = BaseColumns._ID;
    public static final String COLUMN_FRIEND_USERNAME = "username";
    public static final String COLUMN_FRIEND_FC = "fc";
    public static final String COLUMN_FRIEND_MAIN = "main";




}
}