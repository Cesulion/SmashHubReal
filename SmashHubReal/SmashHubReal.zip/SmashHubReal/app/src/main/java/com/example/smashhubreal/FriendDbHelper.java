package com.example.smashhubreal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.View;

public class FriendDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="friends.db";
    private static final int DATABASE_VERSION = 1;

    public FriendDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String SQL_CREATE_FRIENDS_TABLE = "CREATE TABLE " +  FriendsContract.FriendsEntry.TABLE_NAME + "("
                + FriendsContract.FriendsEntry.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME + " TEXT NOT NULL, "
                + FriendsContract.FriendsEntry.COLUMN_FRIEND_FC + " TEXT NOT NULL, "
                + FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN + " TEXT NOT NULL);";
        db.execSQL(SQL_CREATE_FRIENDS_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }


    public boolean profileCreated()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                FriendsContract.FriendsEntry.ID,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_MAIN,
                FriendsContract.FriendsEntry.COLUMN_FRIEND_FC};
        Cursor cursor = db.query(
                FriendsContract.FriendsEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);
        boolean isCreated = cursor.moveToFirst();
        cursor.close();
        return isCreated;
    }

    public FriendClass getProfile(){
        String query = "Select * FROM "    + FriendsContract.FriendsEntry.TABLE_NAME + " WHERE " + FriendsContract.FriendsEntry.ID + " = " + "0";
        SQLiteDatabase db = this.getWritableDatabase();

        FriendClass mFriend = null;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()){
            // String id = cursor.getString(0);
            String username = cursor.getString(1);
            String fc = cursor.getString(2);
            String main = cursor.getString(3);
            mFriend = new FriendClass(username,fc,main);
        }
        cursor.close();
        return mFriend;
    }
    public void deleteFriend(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(FriendsContract.FriendsEntry.TABLE_NAME, FriendsContract.FriendsEntry.COLUMN_FRIEND_USERNAME   + "    = ?", new String[] { String.valueOf(username)});
    }




}
