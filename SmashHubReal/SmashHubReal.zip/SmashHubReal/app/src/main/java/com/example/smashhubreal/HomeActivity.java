package com.example.smashhubreal;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    RecyclerView calendarRV;
    RecyclerView.Adapter calendarRVAdapter;
    ProgressDialog mProgressDialog;
    private DatabaseReference db;
    private HomeDbHelper mDatabase;
    ArrayList<MessageClass> listMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    //------------ToolBar--------------------------------//
    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
    setSupportActionBar(toolbar);

    //-----------RecyclerView------------------------------//
    calendarRV = findViewById(R.id.rv_home);
        calendarRV.hasFixedSize();
        calendarRV.setLayoutManager(new LinearLayoutManager(this));

    //Real initialization of the database
        FriendDbHelper dbh = new FriendDbHelper(this);
    db = FirebaseDatabase.getInstance().getReference();
    mDatabase = new HomeDbHelper(db);
    listMessage = new ArrayList<MessageClass>();

    getDataFromServer();


    // Setup FAB to open EditorActivity
    FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(HomeActivity.this, HomeEditor.class);
            startActivity(intent);
        }
    });


}

    // Menu icons are inflated just as they were with actionbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        FriendDbHelper dbh = new FriendDbHelper(this);
        switch (item.getItemId()) {
            case R.id.myProfileItem:
                Intent profileIntent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case R.id.tiersItem:
                Intent tiersIntent = new Intent(HomeActivity.this, JsonActivity.class);
                startActivity(tiersIntent);
            break;
            case R.id.homeitem:
                Intent homeIntent = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.friendListItem:
                if(dbh.profileCreated())
                {
                    Intent flIntent = new Intent(HomeActivity.this, FriendsActivity.class);
                    startActivity(flIntent);
                }
                else
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setCancelable(true);
                    builder.setTitle("No profile found");
                    builder.setMessage("You need to create your profile first.");
                    builder.setPositiveButton("Confirm",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });
                    builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;


        }
        return super.onOptionsItemSelected(item);

    }

    //-----RETRIEVING DATA FROM SERVER
    public void getDataFromServer()
    {
        showProgressDialog();
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    for(DataSnapshot postSnapShot:dataSnapshot.getChildren())
                    {
                        MessageClass mess=postSnapShot.getValue(MessageClass.class);
                        listMessage.add(mess);
                        String username = mess.getFriend().getUsername();
                        // calendarRVAdapter.notifyDataSetChanged();
                    }
                }
                hideProgressDialog();
                showingEverything();


            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                hideProgressDialog();
            }
        });
    }

    private void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(HomeActivity.this);
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setIndeterminate(true);
        }
        mProgressDialog.show();
    }

    private void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

    public void showingEverything()
    {
        final List<MessageClass> allMess = listMessage;
        if(allMess.size() > 0){
            calendarRV.setVisibility(View.VISIBLE);
            calendarRVAdapter = new HomeAdapter(this, allMess);
            calendarRV.setAdapter(calendarRVAdapter);
        }else {
            calendarRV.setVisibility(View.GONE);
            Toast.makeText(this, "No messages here. Try posting one !", Toast.LENGTH_LONG).show();
        }
    }
}



