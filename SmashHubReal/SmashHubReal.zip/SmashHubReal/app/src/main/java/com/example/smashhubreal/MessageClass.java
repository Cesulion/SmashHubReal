package com.example.smashhubreal;

public class MessageClass {

    private FriendClass friend;
    private String message;
    private String id;

    public MessageClass(String id, FriendClass friend, String message) {
        this.id = id;
        this.friend = friend;
        this.message = message;

    }

    public MessageClass(FriendClass friend, String message) {
        this.friend = friend;
        this.message = message;

    }

    public MessageClass() {
    }

    public FriendClass getFriend() {
        return friend;
    }

    public void setFriend(FriendClass friend) {
        this.friend = friend;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
