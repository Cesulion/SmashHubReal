package com.example.smashhubreal;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class JsonFetcher extends AsyncTask<Void, Void, Void> {

    String data = "";
    String dataParsed = "";
    String singleParsed = "";



    @Override
    protected Void doInBackground(Void... voids) {
        try {
            URL url = new URL("https://www.pricecharting.com/api/products?t=c0b53bce27c1bdab90b1605249e600dc43dfd1d5&q=Super%20Smash%20Bros");
            HttpURLConnection URLconnexion = (HttpURLConnection) url.openConnection();
            InputStream inputStream = URLconnexion.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while (line != null) {
                line = bufferedReader.readLine();
                data = data + line;
            }
            Log.d("De la merde", data);
            JSONObject JO = new JSONObject(data);
            JSONArray JA = JO.getJSONArray("products");
            Log.d("JSONARRAY", JA.toString());
            data="";
            for (int i = 0; i < JA.length(); i++)
            {
                data = data + JA.getJSONObject(i).getString("console-name") + JA.getJSONObject(i).getString("product-name")+"\n";
            }



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        JsonActivity.data.setText(this.data);

    }
}