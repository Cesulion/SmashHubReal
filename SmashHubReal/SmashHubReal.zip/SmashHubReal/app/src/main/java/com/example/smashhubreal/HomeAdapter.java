package com.example.smashhubreal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.List;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.ViewHolder> {


        private Context context;
        private List<MessageClass> listMessage;
        private HomeDbHelper mDatabase;
        private DatabaseReference db;


        HomeAdapter(Context context, List<MessageClass> listMessage){
            this.context = context;
            this.listMessage = listMessage;
            db = FirebaseDatabase.getInstance().getReference();
            mDatabase = new HomeDbHelper(db);

        }

        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            View view = inflater.inflate(R.layout.rv_home_activity, parent, false);
            return new ViewHolder(view);
        }

        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
            final MessageClass singleMessage = listMessage.get(position);
            viewHolder.tv_message.setText(singleMessage.getMessage());
            viewHolder.tv_username.setText(singleMessage.getFriend().getUsername());

        }
        public int getItemCount() {
            return listMessage.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            TextView tv_message;
            TextView tv_username;



            ViewHolder(View itemView) {
                super(itemView);
                tv_message = itemView.findViewById(R.id.tv_message);
                tv_username = itemView.findViewById(R.id.tv_username);

            }


        }

    }

