package com.example.smashhubreal;

public class FriendClass {
    private String username;
    private String fc;
    private String main;


    public FriendClass(String username, String fc, String main) {
        this.username = username;
        this.fc = fc;
        this.main = main;

    }

    public FriendClass() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFc() {
        return fc;
    }

    public void setFc(String fc) {
        this.fc = fc;
    }

    public String getMain() {
        return main;
    }

    public void setMain(String main) {
        this.main = main;
    }
}
