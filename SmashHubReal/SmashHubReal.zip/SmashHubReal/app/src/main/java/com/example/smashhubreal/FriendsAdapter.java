package com.example.smashhubreal;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class FriendsAdapter extends RecyclerView.Adapter<FriendsAdapter.FriendsViewHolder> {

    private Context context;
    private List<FriendClass> friends;
    private FriendDbHelper mDatabase;

    private ArrayList<FriendClass> mFriends;

    FriendsAdapter(ArrayList<FriendClass> friends){
        mFriends=friends;
    }


    FriendsAdapter(Context context, List<FriendClass> listMeals, OnListItemClickListener listener) {
        this.context = context;
        this.friends = listMeals;
        mDatabase = new FriendDbHelper(context);

    }

    public FriendsViewHolder onCreateViewHolder (ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.friend_list_item, parent, false);
        return new FriendsViewHolder(view);
    }

    public void onBindViewHolder (FriendsViewHolder viewHolder,int position)
    {
        viewHolder.username.setText(mFriends.get(position).getUsername());
        viewHolder.fc.setText(mFriends.get(position).getFc());
        viewHolder.main.setText(mFriends.get(position).getMain());
    }

    public int getItemCount()
    {
        return mFriends.size();
    }


    public class FriendsViewHolder extends RecyclerView.ViewHolder{
        TextView username;
        TextView fc;
        TextView main;
        FriendsViewHolder(View itemView)
        {
            super(itemView);
            username = itemView.findViewById(R.id.usernameView);
            fc = itemView.findViewById(R.id.fcView);
            main = itemView.findViewById(R.id.mainView);

        }
    }
    public interface OnListItemClickListener {
        void onListItemClick(int clickedItemIndex);
    }









}

