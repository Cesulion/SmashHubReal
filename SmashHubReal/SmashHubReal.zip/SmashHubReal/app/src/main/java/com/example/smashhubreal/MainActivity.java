package com.example.smashhubreal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.myProfileItem:
                Intent profileIntent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case R.id.homeitem:
                Intent Intent2 = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(Intent2);
                break;
            case R.id.friendListItem:
                Intent flIntent = new Intent(MainActivity.this, FriendsActivity.class);
                startActivity(flIntent);
                break;


        }
        return super.onOptionsItemSelected(item);
    }
    public void addFriend()
    {
        //EditText editName = findViewById(R.id.addfriendText);
        //String friendName = editName.getText().toString();
    }
}
