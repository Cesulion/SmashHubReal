package com.example.smashhubreal;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class HomeEditor extends AppCompatActivity {

    private EditText ETMessage;
    private HomeDbHelper mDatabase;
    private DatabaseReference db;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_editor);

        // Find all relevant views that we will need to read user input from
        ETMessage = (EditText) findViewById(R.id.edit_message);

        //Initialising calendar db
        db = FirebaseDatabase.getInstance().getReference();
        mDatabase = new HomeDbHelper(db);

        //------------ToolBar--------------------------------//
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.dining:
                Toast.makeText(this, "Saving..", Toast.LENGTH_SHORT).show();
                addMessEditor();
                finish();
                overridePendingTransition(0, 0);
                Intent intent = new Intent(HomeEditor.this, HomeActivity.class);
                startActivity(intent);
                break;


        }
        return super.onOptionsItemSelected(item);


    }

    private void addMessEditor() {
        FriendDbHelper dbh = new FriendDbHelper(this);
        final String message = ETMessage.getText().toString();
        if (dbh.profileCreated()) {

            if (TextUtils.isEmpty(message)) {
                Toast.makeText(HomeEditor.this, "Something went wrong. Check your input values", Toast.LENGTH_LONG).show();
            } else {
                Log.d("TESTWESH", "J'arrive là au moins ?");
                FriendDbHelper dbHelper = new FriendDbHelper(this);
                FriendClass user = dbHelper.getProfile();
                Log.d("TESTWESH", "Ce que j'ai saisi est : " + user.getUsername());
                MessageClass mess = new MessageClass(user, message);
                Log.d("TESTWESH", "Ce que j'ai saisi est : " + mess.getMessage());

                mDatabase.addMessage(mess);

            }
        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle("No profile found");
            builder.setMessage("Tou can't post messages without a profile");
            builder.setPositiveButton("Confirm",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }







}


